# Project Milestones

## zillow-housing-analysis

| Date | Milestone |
|------|-----------|
| 2026-05-02 | Part 1 complete — data profiled, reshaped wide→long, cleaned, 9 features engineered, parquets exported |
| TBD | Part 2 complete — EDA, state/metro comparisons, COVID impact analysis, appreciation distribution |
| TBD | Part 3 complete — housing price predictor model built, evaluated, and documented |

---

## Notes
- Raw data: 1,406 West Coast cities × 121 months (Jun 2015 – Jun 2025)
- Source: Zillow Research ZHVI, All Homes Mid-Tier, neural Zestimate-upgraded series
- 25 cities had sparse ZHVI gaps (2019–2021); imputed via linear interpolation within each city's time series
- Processed files: `data/processed/zhvi_long.parquet` (170,126 rows), `data/processed/city_snapshot.parquet` (1,406 rows)
